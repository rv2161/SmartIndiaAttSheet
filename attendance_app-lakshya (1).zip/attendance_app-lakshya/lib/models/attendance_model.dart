class Attendance {
  final String date;
  final bool present;

  Attendance({required this.date, required this.present});
}